<footer class="footer">
    © {{date('Y-m-d')}} Design & Developed by US
</footer>
